-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 29, 2012 at 04:28 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wall`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(250) CHARACTER SET utf8 NOT NULL,
  `date_posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  KEY `post_id` (`post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `message`, `date_posted`, `user_id`) VALUES
(2, 'Goodluck sating magdedefense!', '2012-10-19 18:16:18', 2),
(37, 'Hello World', '2012-10-24 05:21:09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE IF NOT EXISTS `replies` (
  `reply_id` int(11) NOT NULL AUTO_INCREMENT,
  `reply_message` varchar(250) CHARACTER SET utf8 NOT NULL,
  `reply_posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`reply_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `replies`
--

INSERT INTO `replies` (`reply_id`, `reply_message`, `reply_posted`, `post_id`, `user_id`) VALUES
(3, ':)', '2012-10-19 18:53:56', 1, 1),
(5, 'ah', '2012-10-20 04:58:32', 1, 2),
(7, 'thanks God!', '2012-10-21 05:02:56', 1, 1),
(13, 'goodluck Jesse :)', '2012-10-23 22:37:09', 2, 1),
(16, 'Hello Frencheska :)', '2012-10-24 05:25:34', 37, 2),
(15, 'okay', '2012-10-24 05:20:58', 35, 1),
(17, 'wow Frencheska pa rin! Basta Ako si John Lloyd :D', '2012-10-24 05:27:39', 37, 3),
(18, 'haha... sure! Basta si Arvin si Belly ', '2012-10-24 05:28:24', 37, 1),
(19, 'anong kaguluhan toh?\r\nLife changing :)', '2012-10-24 16:34:56', 37, 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(50) NOT NULL,
  `registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `registered`) VALUES
(1, 'lyjen049', 'lyjen@yahoo.com', 'fb41f27899881ea34c42e0930627ec3d', '2012-10-13 11:20:53'),
(2, 'jesse28', 'jesse@yahoo.com', '1613f68d4833cc0b211938659a2b7c07', '2012-10-13 15:34:31'),
(3, 'zeus360', 'zeus@yahoo.com', '584ebc1c73dd34de95fadb0ca57f96ce', '2012-10-22 21:36:34'),
(4, 'prince', 'vin@yahoo.com', '37e3901ac8332044f779133284bc989a', '2012-10-22 21:39:25'),
(22, 'lyjen0498', 'lyje@yahoo.com', '9728f09877a189b09cd53193064fe292', '2012-10-24 04:56:39');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
